package com.ayfox.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot3InitApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot3InitApplication.class, args);
	}

}
